from fastapi import APIRouter, HTTPException, Request, Header
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import httpx, os, re, time, hashlib
from typing import Optional

router = APIRouter(prefix="/tx/erc20", tags=["tx-erc20"])


# ---- rate limit (redis) for tx_erc20 ----
REDIS_URL = (os.getenv("REDIS_URL", "") or "").strip()

RL_TTL_SEC = int((os.getenv("RL_SENDRAW_TTL_SEC", "70") or "70").strip())
RL_DRYRUN_IP_PER_MIN = int((os.getenv("RL_DRYRUN_IP_PER_MIN", "30") or "30").strip())
RL_DRYRUN_KEY_PER_MIN = int((os.getenv("RL_DRYRUN_KEY_PER_MIN", "120") or "120").strip())
RL_PREPARE_IP_PER_MIN = int((os.getenv("RL_PREPARE_IP_PER_MIN", "30") or "30").strip())
RL_PREPARE_KEY_PER_MIN = int((os.getenv("RL_PREPARE_KEY_PER_MIN", "120") or "120").strip())

def _env(name: str, default: str = "") -> str:
    return (os.getenv(name) or default).strip()

def _require_internal_key(x_guardian_key: str | None):
    expected = _env("GUARDIAN_INTERNAL_API_KEY", "")
    if not expected:
        raise HTTPException(status_code=500, detail="GUARDIAN_INTERNAL_API_KEY not set")
    if not x_guardian_key or x_guardian_key.strip() != expected:
        raise HTTPException(status_code=401, detail="unauthorized")

def _client_ip(request: Request) -> str:
    xf = (request.headers.get("x-forwarded-for") or "").split(",")[0].strip()
    if xf:
        return xf
    return (request.client.host if request.client else "unknown") or "unknown"

def _kid_from_key(x_guardian_key: str | None) -> str:
    if not x_guardian_key:
        return "none"
    h = hashlib.sha256(x_guardian_key.encode("utf-8")).hexdigest()
    return h[:12]

def _rl_cfg(action: str):
    a = (action or "").lower()
    if a == "dryrun":
        return RL_DRYRUN_IP_PER_MIN, RL_DRYRUN_KEY_PER_MIN
    if a == "prepare":
        return RL_PREPARE_IP_PER_MIN, RL_PREPARE_KEY_PER_MIN
    return RL_DRYRUN_IP_PER_MIN, RL_DRYRUN_KEY_PER_MIN

async def _rate_limit(action: str, request: Request, x_guardian_key: str | None):
    # toggle via same switch (keep it simple)
    if (_env("RL_SENDRAW_ENABLED", "1") == "0"):
        return None
    if not REDIS_URL:
        raise HTTPException(status_code=500, detail="REDIS_URL not set (rate limit enabled)")
    try:
        import redis.asyncio as redis  # type: ignore
    except Exception:
        raise HTTPException(status_code=500, detail="redis package missing (pip install redis)")

    now = int(time.time())
    minute = now // 60
    retry_after = 60 - (now % 60)

    ip = _client_ip(request)
    kid = _kid_from_key(x_guardian_key)

    ip_lim, key_lim = _rl_cfg(action)

    k_ip = f"rl:{action}:{ip}:{minute}"
    k_key = f"rl:{action}:key:{kid}:{minute}"

    r = redis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)
    try:
        pipe = r.pipeline()
        pipe.incr(k_ip); pipe.expire(k_ip, RL_TTL_SEC)
        pipe.incr(k_key); pipe.expire(k_key, RL_TTL_SEC)
        ip_count, _, key_count, _ = await pipe.execute()

        if int(ip_count) > int(ip_lim) or int(key_count) > int(key_lim):
            headers = {"Retry-After": str(retry_after)}
            return JSONResponse(
                status_code=429,
                content={"detail": "rate_limited", "retry_after": retry_after, "action": action},
                headers=headers,
            )
    finally:
        try:
            await r.aclose()
        except Exception:
            pass
    return None
RPC = os.getenv("BSC_RPC", "https://bsc-dataseed.binance.org/")
CHAIN_ID = 56

ALLOW_TOKEN = set(a.lower() for a in os.getenv("TX_ALLOW_TOKEN", "").split(",") if a.strip())
if not ALLOW_TOKEN:
    ALLOW_TOKEN.add("0xacb0a09414cea1c879c67bb7a877e4e19480f022")

MAX_AMOUNT_RAW = int(os.getenv("TX_MAX_AMOUNT_RAW", "1000000000000000000"))  # default 1000 tokens if 15 decimals? adjust as needed

def _is_addr(a: str) -> bool:
    return bool(re.fullmatch(r"0x[a-fA-F0-9]{40}", a or ""))

def _addr32(a: str) -> str:
    return a.lower().replace("0x","").rjust(64, "0")

def _u256hex(x: int) -> str:
    if x < 0:
        raise ValueError("amount must be >= 0")
    return hex(x)[2:].rjust(64, "0")

async def _rpc(method: str, params, idv: int = 1):
    payload = {"jsonrpc":"2.0","method":method,"params":params,"id":idv}
    async with httpx.AsyncClient(timeout=20.0) as client:
        r = await client.post(RPC, json=payload)
        r.raise_for_status()
        j = r.json()
        if "error" in j:
            raise RuntimeError(j["error"].get("message","rpc error"))
        return j["result"]

async def _eth_call(to: str, data: str, from_addr: Optional[str] = None):
    call_obj = {"to": to, "data": data}
    if from_addr:
        call_obj["from"] = from_addr
    return await _rpc("eth_call", [call_obj, "latest"])

async def _estimate_gas(to: str, data: str, from_addr: Optional[str] = None):
    call_obj = {"to": to, "data": data}
    if from_addr:
        call_obj["from"] = from_addr
    res = await _rpc("eth_estimateGas", [call_obj])
    return int(res, 16)

class TransferBuildIn(BaseModel):
    token: str
    to: str
    amount_raw: int
    from_addr: Optional[str] = None

class TransferBuildOut(BaseModel):
    chainId: int
    to: str
    data: str
    value: str
    gas_estimate: int
    gas_error: Optional[str] = None

class TransferSimIn(BaseModel):
    token: str
    from_addr: str
    to: str
    amount_raw: int

@router.post("/transfer/build", response_model=TransferBuildOut)
async def build_transfer(body: TransferBuildIn):
    if not _is_addr(body.token): raise HTTPException(400, "invalid token address")
    if body.token.lower() not in ALLOW_TOKEN: raise HTTPException(403, "token not allowed")
    if not _is_addr(body.to): raise HTTPException(400, "invalid recipient address")
    if body.from_addr and not _is_addr(body.from_addr): raise HTTPException(400, "invalid from address")
    if int(body.amount_raw) > MAX_AMOUNT_RAW: raise HTTPException(400, "amount_raw exceeds limit")

    data = "0xa9059cbb" + _addr32(body.to) + _u256hex(int(body.amount_raw))

    gas = 0
    gas_error = None
    try:
        gas = await _estimate_gas(body.token, data, from_addr=body.from_addr)
    except Exception as e:
        gas_error = str(e)

    return TransferBuildOut(chainId=CHAIN_ID, to=body.token, data=data, value="0x0", gas_estimate=gas, gas_error=gas_error)

@router.post("/transfer/simulate")
async def simulate_transfer(body: TransferSimIn):
    if not _is_addr(body.token): raise HTTPException(400, "invalid token address")
    if body.token.lower() not in ALLOW_TOKEN: raise HTTPException(403, "token not allowed")
    if not _is_addr(body.from_addr): raise HTTPException(400, "invalid from address")
    if not _is_addr(body.to): raise HTTPException(400, "invalid recipient address")
    if int(body.amount_raw) > MAX_AMOUNT_RAW: raise HTTPException(400, "amount_raw exceeds limit")

    data = "0xa9059cbb" + _addr32(body.to) + _u256hex(int(body.amount_raw))
    try:
        res = await _eth_call(body.token, data, from_addr=body.from_addr)
        return {"ok": True, "eth_call_result": res}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"reverted_or_failed: {e}")

@router.post("/transfer/dryrun")
async def dryrun(body: TransferSimIn, request: Request, x_guardian_key: str | None = Header(default=None)):
    # 1) simulate
    sim = await simulate_transfer(body)

    # 2) nonce + gasPrice + balance
    bal_hex = await _rpc("eth_getBalance", [body.from_addr, "latest"])
    nonce_hex = await _rpc("eth_getTransactionCount", [body.from_addr, "pending"])
    gas_price = await _rpc("eth_gasPrice", [])
    gas = 0
    gas_err = None

    # 3) estimate gas (best effort)
    data = "0xa9059cbb" + _addr32(body.to) + _u256hex(int(body.amount_raw))
    try:
        gas = await _estimate_gas(body.token, data, from_addr=body.from_addr)
    except Exception as e:
        gas_err = str(e)

    return {
        "ok": True,
        "simulate": sim,
        "balance_hex": bal_hex,
        "nonce_hex": nonce_hex,
        "gasPrice_hex": gas_price,
        "gas_estimate": gas,
        "gas_error": gas_err,
        "tx": {"chainId": CHAIN_ID, "to": body.token, "value": "0x0", "data": data},
    }


@router.post("/transfer/prepare")
async def prepare(body: TransferSimIn, request: Request, x_guardian_key: str | None = Header(default=None)):
    # Uses dryrun info, plus computes max fee
    dr = await dryrun(body, request, x_guardian_key)
    gas = int(dr.get("gas_estimate") or 0)
    if gas <= 0:
        gas = 120000

    gas_price_hex = dr.get("gasPrice_hex") or "0x0"
    nonce_hex = dr.get("nonce_hex") or "0x0"
    # compute fee in wei: gas * gasPrice
    gas_price = int(gas_price_hex, 16)
    fee_wei = gas * gas_price

    return {
        "ok": True,
        "nonce_hex": nonce_hex,
        "gasPrice_hex": gas_price_hex,
        "gas": gas,
        "maxFeeWei": str(fee_wei),
        "maxFeeBNB": fee_wei / 1e18,
        "tx": dr.get("tx"),
    }


